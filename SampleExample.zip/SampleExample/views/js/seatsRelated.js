﻿function changeSeatsValues(resposeText) {
    //update seats 
    alert("hi");
    for (var i = 0; i < resposeText.length; i++) {
        var seats = resposeText[i].user_seats;
        for (var j = 0; j < seats.length; j++) {
            document.getElementById(seats[j].id).checked = true;
            document.getElementById(seats[j].id).disabled = true;
        }
    }
}