﻿function ajaxRequest(requestName, url, functionName, value,pageLoad) {
    alert(url);
    var xhttp = new XMLHttpRequest();
    xhttp.open(requestName,url, true);
    xhttp.setRequestHeader("Content-Type", "application/json");
    xhttp.send(value);
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var json = (xhttp.responseText);

            //document.write(xhttp.responseText);
            if (pageLoad != "") {
                window.location.replace(pageLoad);
            }
            if (functionName != "") {
                var temp = functionName + '(' + xhttp.responseText + ')';
                eval(temp);
            }
        }
    };
}