'use strict';
var http = require('http');
var port = process.env.PORT || 1337;
const express = require("express");
var cookieParser = require('cookie-parser');
var session = require('express-session');
const app = express();
var router = express.Router();
var path = __dirname + '/views/';
var bodyParser = require('body-parser');
app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies
console.log(path);
// initialize cookie-parser to allow us access the cookies stored in the browser. 
app.use(cookieParser());

// initialize express-session to allow us track the logged-in user across sessions.
app.use(session({
    key: 'user_sid',
    secret: 'seatbooking-session',
    resave: false,
    saveUninitialized: false,
    cookie: {
        expires: 600000
    }
}));
app.use(express.static('views'));
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/mydb";
MongoClient.connect(url, function (err, db) {
    if (err) throw err;
    console.log("Database created!");
    db.close();
});
router.use(function (req, res, next) {
    console.log("/" + req.method);
    //login user not exist if cookies exist
     if (req.cookies.user_sid && (!req.session.email || !req.session.username)) {
        res.clearCookie('user_sid');        
    }
    next();
});

// middleware function to check for logged-in users
var sessionChecker = (req, res, next) => {
    if ((req.session.email && req.session.username) && req.cookies.user_sid) {
        console.log("session detected")
        res.sendFile(path + "home.html");
    } else {
        next();
    }    
};
router.get("/", function (req, res) {
    res.sendFile(path + "index.html");
});

router.post("/login", function (req, res) {
    console.log(JSON.stringify(req.body));
    var user_id = req.body.id;
    var name = req.body.name;
    var userEmail = req.body.email;
    //db connection
    var myobj = req.body;
    MongoClient.connect(url, function (err, db) {
        if (err) throw err;
        var dbo = db.db("mydb");
        var query = { email: userEmail };
        dbo.collection("customers").find(query).toArray(function (err, result) {
            if (err) throw err;
            console.log(result);
            if (result.length == 0) {
                dbo.collection("customers").insertOne(myobj, function (err, res) {
                    if (err) throw err;
                    console.log("1 user inserted");
                    req.session.email = userEmail;
                    req.session.name = name;
                    db.close();
                });
            } else {
                //result
                console.log("exit user logged in");
                req.session.email = result[0].email;
                req.session.name = result[0].name;
            }

            db.close();
            res.sendFile(path + "home.html");
        });
    });
    
});

router.post("/seatBooking", function (req, res) {
    console.log("session info in seat booking:" + req.session.email + " , " + req.cookies.user_sid);
    if (req.session.email && req.cookies.user_sid) {
        //insert data into session user relate seat booking and return response
        var myobj = { email: req.session.email, "user_seats": req.body.user_seats };
        MongoClient.connect(url, function (err, db) {
            if (err) throw err;
            var dbo = db.db("mydb");
            dbo.collection("seatsTheater").insertOne(myobj, function (err, db_res) {
                if (err) throw err;
                console.log("user booked seats inserted");
                db.close();
                res.sendFile(path + "test.html");
            });
        });
    }
    else {
        //redirect to login page
        console.log("no session for seat booking")
    }
  
});

router.post("/seats-info", function (req, res) {
    console.log("session info:" + req.session.email + " , " + req.cookies.user_sid);
    if (req.session.email && req.cookies.user_sid) {
        //get data of booked seats for date and time wise
        MongoClient.connect(url, function (err, db) {
            if (err) throw err;
            var dbo = db.db("mydb");
            dbo.collection("seatsTheater").find({}, { projection: { _id: 0,user_seats: 1} }).toArray(function (err, result) {
                if (err) throw err;
                console.log("got seats info")
                console.log("seats-info: " + JSON.stringify(result));
                db.close();
                req.session.email = req.session.email;
                req.session.name = req.session.name;
                res.send(JSON.stringify(result));
            });
        });
        
    }
    else {
        //redirect to login page
        console.log("no session");
    }
});
router.get("/home", function (req, res) {
    if (req.session.email && req.cookies.user_sid) {
        //get data of booked seats for date and time wise
        console.log("session detected then direct home page");
        req.session.email = req.session.email;
        req.session.name = req.session.name;
        res.sendFile(path + "home.html");

    }
    else {
        //redirect to login page
        console.log("no session in home");
    }
});
app.use("/", router);

/*app.use("*", function (req, res) {
    res.sendFile(path + "404.html");
});*/

app.listen(3000, function () {
    console.log("Live at Port 3000");
});
